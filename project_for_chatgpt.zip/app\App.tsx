import React from 'react';
import Index from './index';


export default function App() {
  return <Index />;
}